export LD_LIBRARY_PATH=/opt/gurobi602/linux64/lib/:$(pwd)/../lemon/lemon-1.3.1/lib
