Sample instances downloaded from the OR-Library: http://people.brunel.ac.uk/~mastjjb/jeb/info.html

For more instances for the set covering problem, please go to
	http://people.brunel.ac.uk/~mastjjb/jeb/orlib/scpinfo.html