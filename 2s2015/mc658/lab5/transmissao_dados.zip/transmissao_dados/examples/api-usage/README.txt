Plain driver: a sample driver and Decoder class that make use of the BRKGA API. Additional
documentation can be found in the source file api-usage.cpp.

To recompile and run the program, type:
	cd ./examples/api-usage
	make clean
	make
	./api-usage
	
To modify any of the BRKGA parameters, edit the file api-usage.cpp and recompile the program.
